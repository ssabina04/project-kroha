import React from 'react';
import Kater from './Kater/Kater';

const Kategoriaa = () => {
    return (
        <div>
            <Kater />
        </div>
    );
};

export default Kategoriaa;